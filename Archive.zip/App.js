import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';

import FrontTermsScreen from './src/screens/FrontTermsScreen';
import TermTitlesScreen from './src/screens/TermTitlesScreen';
import ArticleScreen from './src/screens/ArticleScreen';
import AboutAppScreen from './src/screens/AboutAppScreen';
import SettingsScreen from './src/screens/SettingsScreen';


const navigator = createStackNavigator({
  Front: FrontTermsScreen,
  Titles: TermTitlesScreen,
  Article: ArticleScreen,
  About : AboutAppScreen,
  Settings: SettingsScreen,
}, {
  initialRouteName: 'Front',
  defaultNavigationOptions: {
    title: 'New Muslim Guide'
  }
});

export default createAppContainer(navigator);