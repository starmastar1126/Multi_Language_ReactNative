import React from 'react';
import { AsyncStorage } from 'react-native';

export default () => {
    // AsyncStorage.setItem('defaultLanguage', 'English');
    // let lang = 'English';
    // let language = await AsyncStorage.getItem('defaultLanguage');
    // if(lang == 'English') {
        const bookData = require('../json/Default.json');
    // }
    return bookData;
}