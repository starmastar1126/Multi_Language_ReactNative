import React, {useEffect, useState} from 'react';
import {StyleSheet, View, Text} from 'react-native';


const AboutAppScreen = () => {

    return (
        <View>
            <Text>About</Text>
        </View>
    );
}


const styles = StyleSheet.create({
    container: {
        backgroundColor: '#f8f8f8'
    }
});

export default AboutAppScreen;