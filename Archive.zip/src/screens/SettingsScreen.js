import React from 'react';
import {StyleSheet, View, Text, FlatList, TouchableOpacity} from 'react-native';



const languagesList = require('../json/Languages.json');

const SettingsScreen = () => {
    const changeLanguage = (item) => {
        console.log(item);
    }

    return (
        <View>
            <Text>Settings</Text>
            <FlatList
                data={languagesList}
                renderItem = {({item}) => <TouchableOpacity onPress={() => changeLanguage(item)}><Text>{item.nativeName}</Text></TouchableOpacity>}
                keyExtractor = {(item) => item.code}
            />
        </View>
    );
}


const styles = StyleSheet.create({
    container: {
        backgroundColor: '#f8f8f8'
    }
});

export default SettingsScreen;