import React, {useEffect, useState} from 'react';
import {StyleSheet, View, Text, TouchableOpacity} from 'react-native';
import { filterResultsByTermId, filterResultsToGetIntros } from '../hooks/hooks'
import TermsList from '../components/TermsList';
import IntrosList from '../components/IntrosList';
import { Feather } from '@expo/vector-icons';


const FrontTermsScreen = () => {
    const [firstTerms, setFirstTerms] = useState(null);
    const [secondTerms, setSecondTerms] = useState(null);
    const [intros, setIntros] = useState(null);

    useEffect(()=>{
        setFirstTerms(filterResultsByTermId(6));
        setSecondTerms(filterResultsByTermId(12));
        setIntros(filterResultsToGetIntros());
    }, []);
    return (
        <View style={styles.container}>
            <TermsList results={firstTerms}/>
            <IntrosList results={intros}/>
            <TermsList results={secondTerms}/>
        </View>
    );
}

FrontTermsScreen.navigationOptions = ({navigation}) => {
    return {
        headerRight:<TouchableOpacity onPress={() => navigation.navigate('Settings')}>
                        <Feather name="settings" size={20} />
                    </TouchableOpacity>,
        headerLeft: <TouchableOpacity onPress={() => navigation.navigate('About')}>
                        <Feather name="info" size={20} />
                    </TouchableOpacity>,
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#f8f8f8'
    }
});

export default FrontTermsScreen;