const fs = require("fs");
const files = fs.readdirSync("../../src/json").filter(x => x.includes("json"));
const ex = "{\n" +
files.map(x => `"${x.split(".json")[0]}": require("../json/${x}"),`).join("\n") + "}";
const res = "export default " + ex;
fs.writeFileSync("../../src/json/index.js", res);